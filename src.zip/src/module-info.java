module PrisonBreak {
	requires gson;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
	opens de.webdesignfeilbach.prisonbreak.tests;
	opens de.webdesignfeilbach.prisonbreak.game;
	
}