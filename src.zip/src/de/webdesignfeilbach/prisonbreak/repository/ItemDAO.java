package de.webdesignfeilbach.prisonbreak.repository;

import java.util.List;

import de.webdesignfeilbach.prisonbreak.items.Item;


/**
 * 
 * Interface zur Kommunikation mit der JSON Datei: items.json

 * @author Dominik Feilbach
 *
 */
public interface ItemDAO {
	/** KLASSISCHES DAO DESIGN */
	List<Item> getAllItems();
	void addItem(Item item);
	void updateItem(Item item);
	void deleteItem(Item item);
	
}

