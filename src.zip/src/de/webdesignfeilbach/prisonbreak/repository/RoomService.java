package de.webdesignfeilbach.prisonbreak.repository;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import de.webdesignfeilbach.prisonbreak.rooms.Room;

/**
 * 
 * Datenverarbeitung der Liste aller R�ume von RoomDAOImplJSON. </br>
 * Datenquelle wird von der Main �bergeben. </br>
 * Service soll Methoden zur Filterung der Daten enthalten,
 * welche auf den Auswahlkriterien der Klasse Auswahlkriterien beruhen.
 * 
 * @author Dominik Feilbach
 *
 */
public class RoomService {
	private List<Room> alleRooms;

	
	public RoomService(RoomDAO datenquelle) {
		alleRooms = datenquelle.getAllRooms();
	}
	
	public List<Room> getAlleRooms(){
		return alleRooms;
	}
	
	public List<Room> filtern(Predicate<Room> kriterium) {
		return alleRooms.stream().filter(kriterium).collect(Collectors.toList());
	}
	
	public List<Room> filtern(List<Room> auswahlListe, Predicate<Room> kriterium) {
		return auswahlListe.stream().filter(kriterium).collect(Collectors.toList());
	}
	
	public List<Room> filtern(Predicate<Room> kriterium1, Predicate<Room> kriterium2) {
		
		return alleRooms.stream().filter(kriterium1).filter(kriterium2).collect(Collectors.toList());
	}
	
}
