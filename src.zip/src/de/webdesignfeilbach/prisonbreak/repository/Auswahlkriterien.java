package de.webdesignfeilbach.prisonbreak.repository;

import java.util.function.Predicate;

import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

/**
 * 
 * Interface zur Auswahl/Filterung aller: </br>
 * - R�ume </br>
 * - Items </br>
 * 
 * @author Dominik Feilbach
 *
 */
public interface Auswahlkriterien {
	//ITEMS
	public static final Predicate<Item> IST_APFEL = (item -> item.getItemId().equalsIgnoreCase("apfel"));
	public static final Predicate<Item> IST_BROT = (item -> item.getItemId().equalsIgnoreCase("brot"));
	public static final Predicate<Item> IST_MILCH = (item -> item.getItemId().equalsIgnoreCase("milch"));
	public static final Predicate<Item> IST_PISTOLE = (item -> item.getItemId().equalsIgnoreCase("pistole"));
	public static final Predicate<Item> IST_MESSER = (item -> item.getItemId().equalsIgnoreCase("messer"));
	public static final Predicate<Item> IST_SCHLUESSEL = (item -> item.getItemId().equalsIgnoreCase("schluessel"));
	public static final Predicate<Item> IST_WASSER = (item -> item.getItemId().equalsIgnoreCase("wasser"));
	public static final Predicate<Item> IST_LOEFFEL = (item -> item.getItemId().equalsIgnoreCase("loeffel"));
	
	
	//ROOMS
	public static final Predicate<Room> IST_ZUHAUSE = (room -> room.getRoomID().equalsIgnoreCase("zuhause"));
	public static final Predicate<Room> IST_SUPERMARKT = (room -> room.getRoomID().equalsIgnoreCase("supermarkt"));
	public static final Predicate<Room> IST_BANK = (room -> room.getRoomID().equalsIgnoreCase("bank"));
	public static final Predicate<Room> IST_TATTOOSTUDIO = (room -> room.getRoomID().equalsIgnoreCase("tattoostudio"));
	public static final Predicate<Room> IST_ZELLE = (room -> room.getRoomID().equalsIgnoreCase("zelle"));
	public static final Predicate<Room> IST_WACHRAUM = (room -> room.getRoomID().equalsIgnoreCase("wachraum"));
	public static final Predicate<Room> IST_HOF = (room -> room.getRoomID().equalsIgnoreCase("hof"));
	public static final Predicate<Room> IST_FLUR = (room -> room.getRoomID().equalsIgnoreCase("flur"));
	
	
	
	
	
	
}
