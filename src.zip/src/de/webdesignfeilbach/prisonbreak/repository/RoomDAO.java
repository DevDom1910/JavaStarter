package de.webdesignfeilbach.prisonbreak.repository;

import java.util.List;

import de.webdesignfeilbach.prisonbreak.rooms.Room;

/**
 * 
 * Interface zur Kommunikation mit der JSON Datei: rooms.json

 * @author Dominik Feilbach
 *
 */
public interface RoomDAO {
	/** KLASSISCHES DAO DESIGN */
	List<Room> getAllRooms();
	void addRoom(Room room);
	void updateRoom(Room room);
	void deleteRoom(Room room);
	
	
}
