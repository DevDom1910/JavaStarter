package de.webdesignfeilbach.prisonbreak.repository;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.rooms.Cell;
import de.webdesignfeilbach.prisonbreak.rooms.LocationType;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

/**
 * 
 * Klasse fragt alle R�ume in der JSON Datei "rooms.json" ab und erstellt alle R�ume.</br>
 * Service soll Methode getAllRooms aufrufen und alle R�ume in einer Liste erhalten.
 * 
 * @author Dominik Feilbach
 *
 */

public class RoomDAOImplJSON implements RoomDAO {
	/** Liste aller Rooms die aus der JSON Datei geholt wurden */
	private List<Room> alleRooms = new ArrayList<>();
	
	
	

	/**
	 * Abfragen aller R�ume aus der JSON DATEI und Aufruf der Load Methode </br>
	 * In dieser Methode wird die Datei ausgew�hlt und die load Methode aufgerufen. </br>
	 * R�ckgabe der Liste aller R�ume aus der JSON Datei. </br>
	 * Methode wird durch den Service aufgerufen.
	 * 
	 * @return alleItems
	 */
	public List<Room> getAllRooms() {
		/** Auswahl des Pfads */
		File path = new File(new File(System.getProperty("user.dir")), "ressources");
		/** Auswahl der Datei im entsprechenden Pfad */
		File dataFile = new File(path, "rooms.json");
		
		/**
		 * Aufruf der load-Methode, wenn Datei vorhanden.
		 */
		try {
			JsonReader reader = new JsonReader(new FileReader(dataFile));
			//EIGENTLICHES INITIALISIEREN DER ROOMS
			load(reader);
			reader.close();
			return alleRooms;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return null;

	}

	/**
	 * Laden aller Rooms aus der JSON Datei und erstellen eines neuen Item Objekt.
	 * Das Objekt wird der Liste alleItems hinzugef�gt, damit diese sp�ter in der
	 * Methode getAllRooms zur�ck gegeben werden kann
	 * 
	 * @param reader
	 */
	private void load(JsonReader reader) {

		JsonObject jsonRooms = new JsonObject();
		JsonParser parser = new JsonParser();
		JsonObject json = parser.parse(reader).getAsJsonObject();
		jsonRooms = json.get("rooms").getAsJsonObject();

		for (Map.Entry<String, JsonElement> eintragRoom : jsonRooms.entrySet()) {

			String roomID = eintragRoom.getKey();
			JsonObject roomData = eintragRoom.getValue().getAsJsonObject();
			String name = roomData.get("name").getAsString();
			String beschreibung = roomData.get("beschreibung").getAsString();
			boolean open = roomData.get("open").getAsBoolean();
			int gefahrenstufe = roomData.get("gefahrenstufe").getAsInt();
			
			// Typ Umwandlung
			String typ = roomData.get("typ").getAsString();
			LocationType roomTyp;
			switch (typ) {
			case "frei":
				roomTyp = LocationType.FREI;
				break;
			case "gefangen":
				roomTyp = LocationType.GEFANGEN;
				break;
			default:
				roomTyp = LocationType.GEFANGEN;
				break;
			}

			// NPCS
			JsonObject npcs = roomData.get("npc").getAsJsonObject();
			List<NPC> alleNPCS = new ArrayList<>();
			if (npcs != null) {
				for (Map.Entry<String, JsonElement> eintragNPCS : npcs.entrySet()) {
					String nameNPC = eintragNPCS.getValue().getAsString();
					NPC neuesNPC = new NPC(nameNPC);
					alleNPCS.add(neuesNPC);
				}
			}
			
			/** Entscheidung, da bestimmter Raum entprechend instanziert werden muss */
			Room neuerRoom;
			if (roomID.equalsIgnoreCase("zelle")) {
				neuerRoom = new Cell(roomID, name, beschreibung, roomTyp, gefahrenstufe, open, alleNPCS);
			}else {
				neuerRoom = new Room(roomID, name, beschreibung, roomTyp, gefahrenstufe, open, alleNPCS);
			}
			

			alleRooms.add(neuerRoom);
		}
	}
	
	
	
	
	
	
	

	@Override
	public void addRoom(Room room) {
		System.out.println("Befindet sich in Arbeit");

	}

	@Override
	public void updateRoom(Room room) {
		System.out.println("Befindet sich in Arbeit");

	}

	@Override
	public void deleteRoom(Room room) {
		System.out.println("Befindet sich in Arbeit");

	}

}
