package de.webdesignfeilbach.prisonbreak.repository;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import de.webdesignfeilbach.prisonbreak.items.Item;
/**
 * 
 * Datenverarbeitung der Liste aller Items von ItemDAOImplJSON. </br>
 * Datenquelle wird von der Main �bergeben. </br>
 * Service soll Methoden zur Filterung der Daten enthalten,
 * welche auf den Auswahlkriterien der Klasse Auswahlkriterien beruhen.
 * 
 * @author Dominik Feilbach
 *
 */
public class ItemService {
	private List<Item> alleItems;
	
	public ItemService(ItemDAO datenquelle) {
		alleItems = datenquelle.getAllItems();
	}
	
	public List<Item> getAlleItems(){
		return alleItems;
	}
	
	
	public List<Item> filtern(Predicate<Item> kriterium) {
		return alleItems.stream().filter(kriterium).collect(Collectors.toList());
	}
	
	public List<Item> filtern(List<Item> auswahlListe, Predicate<Item> kriterium) {
		return auswahlListe.stream().filter(kriterium).collect(Collectors.toList());
	}
	
	public List<Item> filtern(Predicate<Item> kriterium1, Predicate<Item> kriterium2) {
		
		return alleItems.stream().filter(kriterium1).filter(kriterium2).collect(Collectors.toList());
	}

	
	
}
