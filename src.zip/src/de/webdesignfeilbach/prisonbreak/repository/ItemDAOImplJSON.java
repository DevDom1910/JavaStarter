package de.webdesignfeilbach.prisonbreak.repository;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.items.ItemTyp;

/**
 * 
 * Klasse fragt alle Items in der JSON Datei "items.json" ab und erstellt alle Items.</br>
 * Service soll Methode getAllItems aufrufen und alle Items in einer Liste erhalten.
 * 
 * @author Dominik Feilbach
 *
 */

public class ItemDAOImplJSON implements ItemDAO {
	/** Liste aller Items die aus der JSON Datei geholt wurden */
	private List<Item> alleItems = new ArrayList<>();

	/**
	 * Abfragen aller Items aus der JSON DATEI und Aufruf der Load Methode </br>
	 * In dieser Methode wird die Datei ausgew�hlt und die load Methode aufgerufen. </br>
	 * R�ckgabe der Liste aller Items aus der JSON Datei. </br>
	 * Methode wird durch den Service aufgerufen.
	 * 
	 * @return alleItems
	 */
	public List<Item> getAllItems() {
		/** Auswahl des Pfads */
		File path = new File(new File(System.getProperty("user.dir")), "ressources");
		/** Auswahl der Datei im entsprechenden Pfad */
		File dataFile = new File(path, "items.json");
		
		/**
		 * Aufruf der load-Methode, wenn Datei vorhanden.
		 */
		try {
			JsonReader reader = new JsonReader(new FileReader(dataFile));
			load(reader);
			return alleItems;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;

	}

	/**
	 * Laden aller Items aus der JSON Datei und erstellen eines neuen Item Objekt.
	 * Das Objekt wird der Liste alleItems hinzugef�gt, damit diese sp�ter in der
	 * Methode getAllItems zur�ck gegeben werden kann
	 * 
	 * @param reader
	 */
	private void load(JsonReader reader) {
		JsonObject jsonItems = new JsonObject();

		try {
			JsonParser parser = new JsonParser();
			JsonObject json = parser.parse(reader).getAsJsonObject();
			jsonItems = json.get("items").getAsJsonObject();
			reader.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		for (Map.Entry<String, JsonElement> eintragItem : jsonItems.entrySet()) {
			String itemId = eintragItem.getKey();
			JsonObject itemData = eintragItem.getValue().getAsJsonObject();
			String name = itemData.get("name").getAsString();
			String beschreibung = itemData.get("beschreibung").getAsString();

			// Typ Umwandlung
			String typ = itemData.get("typ").getAsString();
			ItemTyp itemTyp;
			switch (typ) {
			case "Essen":
				itemTyp = ItemTyp.ESSEN;
				break;
			case "Waffe":
				itemTyp = ItemTyp.WAFFE;
				break;
			case "Trinken":
				itemTyp = ItemTyp.TRINKEN;
				break;
			case "Ruestung":
				itemTyp = ItemTyp.RUESTUNG;
				break;
			case "Werkzeug":
				itemTyp = ItemTyp.WERKZEUG;
				break;
			default:
				itemTyp = ItemTyp.SONSTIGES;
				System.out.println(
						"Bitte in der items.json Datei nachschauen. Typ '" + typ + "' nicht in ENUM enthalten!");
				break;
			}

			// Eigenschaften
			JsonObject eigenschaften = itemData.get("eigenschaften").getAsJsonObject();
			Map<String, Integer> eigenschaftenMap = new TreeMap<>();
			for (Map.Entry<String, JsonElement> eintragEigenschaft : eigenschaften.entrySet()) {
				String key = eintragEigenschaft.getKey();
				Integer value = eintragEigenschaft.getValue().getAsInt();
				eigenschaftenMap.put(key, value);
			}

			Item neuesItem = new Item(itemId, name, beschreibung, itemTyp, eigenschaftenMap);
			alleItems.add(neuesItem);
		}
	}

	@Override
	public void addItem(Item item) {
		System.out.println("Befindet sich in Arbeit");

	}

	@Override
	public void updateItem(Item item) {
		System.out.println("Befindet sich in Arbeit");

	}

	@Override
	public void deleteItem(Item item) {
		System.out.println("Befindet sich in Arbeit");

	}
}
