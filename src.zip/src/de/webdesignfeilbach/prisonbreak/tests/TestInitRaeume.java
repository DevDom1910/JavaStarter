package de.webdesignfeilbach.prisonbreak.tests;

import java.util.HashMap;
import java.util.Map;

import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.rooms.LocationType;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

public class TestInitRaeume {

	public static void main(String[] args) {


		Room raumARoom = new Room("raumA", "TesttraumA", "Testen von Testraum A", LocationType.FREI, 0, true, null);
		Room raumBRoom = new Room("raumB", "TesttraumB", "Testen von Testraum B", LocationType.GEFANGEN, 0, true, null);

		
		
		Map<String, Room> nachbarVonA = new HashMap<>();
		nachbarVonA.put("nord", raumBRoom);
		raumARoom.setNeighboursRooms(nachbarVonA);
		System.out.println(raumARoom);
		
		
	}

}
