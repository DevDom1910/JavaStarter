package de.webdesignfeilbach.prisonbreak.tests;


import java.io.IOException;

import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import javafx.application.Application;


public class GUITest {
	public static void main(String[] args) throws IOException {
        Application.launch(PrisonBreak.class,args);
    }
	
}

