package de.webdesignfeilbach.prisonbreak.tests;



import java.util.List;
import java.util.Map;

import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

public class JSONTest {

	public static void main(String[] args) {
//		ItemDAOImplJSON test = new ItemDAOImplJSON();
//		List<Item> list = test.getAllItems();
//		for (Item item : list) {
//			System.out.println(item);
//		}
		
		RoomDAOImplJSON test = new RoomDAOImplJSON();
		List<Room> list = test.getAllRooms();
		for (Room room : list) {
			System.out.println(room);
		}

		
	}

}
