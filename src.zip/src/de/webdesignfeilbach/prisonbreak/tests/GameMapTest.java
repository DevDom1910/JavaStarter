package de.webdesignfeilbach.prisonbreak.tests;

import java.util.List;

import de.webdesignfeilbach.prisonbreak.gameplay.GameMap;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAO;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.ItemService;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAO;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

public class GameMapTest {

	public static void main(String[] args) {
		RoomDAO raumquelle = new RoomDAOImplJSON();
		ItemDAO itemquelle = new ItemDAOImplJSON();
		RoomService roomDiener = new RoomService(raumquelle);
		ItemService itemDiener = new ItemService(itemquelle);
		new GameMap(itemDiener, roomDiener);
		
		
		

		
	}

}
