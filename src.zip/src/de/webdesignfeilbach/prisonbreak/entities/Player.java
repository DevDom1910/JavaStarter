package de.webdesignfeilbach.prisonbreak.entities;

/**
 * 
 * Spieler, welcher den Bruder retten muss.</br>
 * Spieler wird nach erfolgreicher Namenseingabe in der GUI erstellt. </br>
 * Der Spieler hat:</br>
 * - einen Namen</br>
 * - ein Inventar</br>
 * - den aktuellen Raum in der er sich befindet</br>
 * - Schaden: 10</br>
 * - lebenspunkte: 100</br>
 * 
 * 
 * 
 * @author Dominik Feilbach
 *
 */

import de.webdesignfeilbach.prisonbreak.items.Inventory;
import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.rooms.LocationType;
import de.webdesignfeilbach.prisonbreak.rooms.Room;

public class Player {
	/** Beispiel: Dominik */
	private String name;
	/** Beispiel: ItemBundles */
	private Inventory inventar;
	/** Beispiel: zuhause */
	private Room currentRoom;
	/** Beispiel: 10 */
	private int schaden;
	/** Beispiel: 100 */
	private int lebenspunkte;
	/** Haftstrafe Zeit */
	private double haftstrafe;

	// KONSTRUKTOR
	public Player(String name, Room currentRoom) {
		this.name = name;
		this.currentRoom = currentRoom;
		this.inventar = new Inventory();
		this.schaden = 10;
		this.lebenspunkte = 100;
		this.haftstrafe = 0;
	}

	
	
	public void erhoehenHaftstrafe(double haftstrafe) {
		this.haftstrafe += haftstrafe;
	}
	
	
	// GETTER/SETTER

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the haftstrafe
	 */
	public double getHaftstrafe() {
		return haftstrafe;
	}

	/**
	 * @param haftstrafe the haftstrafe to set
	 */
	public void setHaftstrafe(double haftstrafe) {
		this.haftstrafe = haftstrafe;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the inventar
	 */
	public Inventory getInventar() {
		return inventar;
	}

	/**
	 * @param inventar the inventar to set
	 */
	public void setInventar(Inventory inventar) {
		this.inventar = inventar;
	}

	/**
	 * @return the currentRoom
	 */
	public Room getCurrentRoom() {
		return currentRoom;
	}

	/**
	 * @param currentRoom the currentRoom to set
	 */
	public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

	/**
	 * @return the schaden
	 */
	public int getSchaden() {
		return schaden;
	}

	/**
	 * @param schaden the schaden to set
	 */
	public void setSchaden(int schaden) {
		this.schaden = schaden;
	}

	/**
	 * @return the lebenspunkte
	 */
	public int getLebenspunkte() {
		return lebenspunkte;
	}

	/**
	 * @param lebenspunkte the lebenspunkte to set
	 */
	public void setLebenspunkte(int lebenspunkte) {
		this.lebenspunkte = lebenspunkte;
	}

	

}
