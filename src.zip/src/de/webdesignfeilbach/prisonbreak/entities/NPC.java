package de.webdesignfeilbach.prisonbreak.entities;

import java.util.Objects;
import java.util.Random;


/**
 * 
 * Diese Klasse beschreibt alle Charaktere, welche nicht vom Spieler gesteuert werden (in diesem Fall: Player). </br>
 * Die NPCS befinden sich in einzelnen R�umen entsprechend der rooms.json Datei
 * 
 * Jeder Bot bekommt: </br>
 * - einen Namen </br>
 * - M�glichkeit zur Interaktion </br>
 * - Lebenspunkte </br>
 * - Schaden
 * 
 * @author Dominik Feilbach
 *
 */

public class NPC {
	//ATTRIBUTE
	/** Beispiel: Rainer */
	private String npcName;
	/** Beispiel: true */
	private boolean canInteract;
	/** Beispiel: 100 */
	private int lebenspunkte;
	/** Beispiel: true */
	private boolean alive;
	/** Beispiel: 25 */
	private int schaden;
	
	/** Bot soll mit dem Spieler interagieren k�nnen. */
	private String[] begruessung = {"Hey mein Freund.", "Hello.", "Hallo.", "Hey."};
	private String[] smalltalk = {"Wie gehts dir?", "Was machst du so?", "Wo willst Du hin?", "Wie gehts der Familie?"};
	private String[] madSituations = {"Bist du verr�ckt!", "Weg hier!"};
	
	
	
	
	//KONSTRUKTOREN	
	public NPC(String npcName) {
		this(npcName, true);
		
	}
	public NPC (String npcName, boolean canInteract) {
		this.npcName = npcName;
		this.canInteract = canInteract;
		this.lebenspunkte = 100;
		this.alive = true;
		this.schaden = 25;
		
	}

	
	/**
	 * Funktion zum Interagieren mit dem Spieler. </br>
	 * Dabei soll die Interaktion entsprechend der �bergebenen Laune konstruiert werden. </br>
	 * Anschlie�end sollen aus gegebenen Array die Antwort durch Zufall ausgesucht und zur�ckgegeben werden.
	 * @param isMad
	 * @return output
	 */
	public String talk(boolean isMad) {
		Random zufall = new Random();
		String output = "";
		if (isMad) {
			int index = zufall.nextInt(madSituations.length);
			output = madSituations[index];
		}else {
			int indexBegruessung = zufall.nextInt(begruessung.length);
			int indexSmallTalk = zufall.nextInt(smalltalk.length);
			output += begruessung[indexBegruessung];
			output += smalltalk[indexSmallTalk];
		}
		return output;
	}
	
	

	//GETTER/SETTER
	/**
	 * @return the npcName
	 */
	public String getNpcName() {
		return npcName;
	}
	/**
	 * @return the alive
	 */
	public boolean isAlive() {
		return alive;
	}
	/**
	 * @param alive the alive to set
	 */
	public void setAlive(boolean alive) {
		this.alive = alive;
	}
	/**
	 * @param npcName the npcName to set
	 */
	public void setNpcName(String npcName) {
		this.npcName = npcName;
	}
	/**
	 * @return the canInteract
	 */
	public boolean isCanInteract() {
		return canInteract;
	}
	/**
	 * @param canInteract the canInteract to set
	 */
	public void setCanInteract(boolean canInteract) {
		this.canInteract = canInteract;
	}
	/**
	 * @return the lebenspunkte
	 */
	public int getLebenspunkte() {
		return lebenspunkte;
	}
	/**
	 * @param lebenspunkte the lebenspunkte to set
	 */
	public void setLebenspunkte(int lebenspunkte) {
		this.lebenspunkte = lebenspunkte;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(canInteract, npcName);
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NPC other = (NPC) obj;
		return canInteract == other.canInteract && Objects.equals(npcName, other.npcName);
	}

	@Override
	public String toString() {
		return "NPC [npcName=" + npcName + ", canInteract=" + canInteract + "]";
	}	
}
