package de.webdesignfeilbach.prisonbreak.commands;

import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.entities.Player;
import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.items.ItemBundle;


/**
 * 
 * Diese Klasse dient als Controller f�r alle Kommandos, die in der GUI abgeschickt werden. </br>
 * Zum momentanen Zeitpunkt ist das Kommando: kill NPC (kill Manfred) aktiv. Alle weiteren Kommandos befinden sich noch in Bearbeitung.
 * Die Klasse soll nicht instanziert werden k�nnen. Die Funktion analyzeCommands soll ohne Instanzierung aufgerufen werden.
 * 
 * 
 * @author Dominik Feilbach
 *
 */
public abstract class Commands {

	public static String analyzeCommands(Player spieler, String input) {
		
		/** 
		 * Anlegen eines Arrays durch Splitten der Kommandoeingabe innerhalb der GUI. </br>
		 * Beispiel: </br>
		 * => Eingabe: kill Manfred </br>
		 * => Array: {"kill", "Manfred"}
		 */
		String[] inputCommand = input.split(" ");
		/**
		 * Aufteilen des erstellten Arrays nach Verb und Action. </br>
		 * Beispiel: </br>
		 * - Verb: kill </br>
		 * - Action: Manfred
		 */
		String verb = "";
		String action = "";
		System.out.println(inputCommand.length);
		if (inputCommand.length == 1) {
			verb = inputCommand[0];
		}else if (inputCommand.length == 2) {
			verb = inputCommand[0];
			action = inputCommand[1];
		}
		
		
		
		/**
		 * Variable zum Filtern der Action (falls ein Item als Action angegeben wurde).
		 */
		Item commandItem = null;
		
		/**
		 * Variable zum Filtern der Action (falls ein NPC als Action angegeben wurde).
		 */
		NPC commandNPC = null;
		
		/**
		 * Variable, welche zur�ckgegeben und in der GUI ausgegeben wird. </br>
		 * Wird durch die Auswahl des Kommandos in der entsprechenden Klasse bef�llt
		 */
		String output = "";

		
		/**
		 * Auswahl anhand der eindeutigen ITEMID innerhalb der aktuellen Raums und Vergleich der Kommandoeingabe. </br>
		 * Bei Erfolg: commandoItem = Item </br>
		 * Bei Misserfolg: commandoItem = null
		 */
		for (ItemBundle itemStack : PrisonBreak.spieler.getCurrentRoom().getItemStacks()) {
			if (itemStack.getItem().getItemId().equalsIgnoreCase(action)) {
				commandItem = itemStack.getItem();
			}
		}

		/**
		 * Auswahl anhand des NPCNAMEN innerhalb des aktuellen Raums und Vergleich der Kommandoeingabe. </br>
		 * Bei Erfolg: commandNPC = NPC </br>
		 * Bei Misserfolg: commandNPC = null
		 */
		for (NPC npc : PrisonBreak.spieler.getCurrentRoom().getNpcs()) {
			if (npc.getNpcName().equalsIgnoreCase(action)) {
				commandNPC = npc;
			}
		}
		
		/**
		 * Vergleich des Kommandos und anschlie�ender Ausf�hrung der entsprechenden Klasse
		 * Beispiel: </br>
		 * Sollte das verb vorhanden sein und der NPC imm aktuellen Raum vorhanden sein, wird die Klasse KillCommand ausgef�hrt. </br>
		 * Sollte das verb vorhanden sein und der NPC nicht im aktuellen Raum sein, wird "Bot nicht vorhanden" zur�ck gegeben werden! </br>
		 * Sollte das verb nicht vorhanden sein, wird "Kommando nicht vorhanden" zur�ckgegeben!
		 */
		switch (verb) {
		case "kill":
			if (commandNPC != null) {
				output = KillCommand.executeCommand(commandNPC);
			}else {
				output = "Bot nicht vorhanden!";
			}
			return output;
		case "dig":
			output = DigCommand.executeCommand();
			
			return output;
//		case "talk":
//			if (commandNPC != null) {
//				output = GUI.spieler.talk(commandNPC);
//			}else {
//				output = "Bot nicht vorhanden";
//			}
//			return output;
//		case "move":
//			if (commandItem != null) {
//				output = GUI.spieler.move(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
//		case "steal":
//			if (commandItem != null) {
//				output = GUI.spieler.steal(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
//		case "sleep":
//			if (commandItem != null) {
//				output = spieler.sleep(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
//		case "open":
//			if (commandItem != null) {
//				output = spieler.open(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
//		case "close":
//			if (commandItem != null) {
//				output = spieler.close(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
//		case "use":
//			if (commandItem != null) {
//				output = spieler.use(commandItem);
//			}else {
//				output = "Item nicht vorhanden!";
//			}
//			return output;
		default:
			output = "Kommando nicht vorhanden!";
			return output;
		}

	}

}
