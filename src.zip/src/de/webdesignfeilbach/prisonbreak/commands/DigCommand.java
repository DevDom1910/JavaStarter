package de.webdesignfeilbach.prisonbreak.commands;

import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.rooms.Cell;
/**
 * 
 * Diese Klasse dient zur Ausf�hrung der DIG Action. </br>
 * Die Klasse soll nicht instanziert werden k�nnen. </br>
 * Aufruf soll durch einen Kommando Controller erfolgen.
 * 
 * 
 * @author Dominik Feilbach
 *
 */
public abstract class DigCommand {
	
	/**
	 * Es ist nur m�glich in der Zelle zu graben. </br>
	 * Der Fortschritt wird um 20 erh�ht. Ist der Fortschritt bei 100 ist das Spiel zu Ende.
	 * 
	 */
	public static String executeCommand() {
		String output = "";
		
		if (PrisonBreak.spieler.getCurrentRoom().getRoomID().equalsIgnoreCase("zelle")) {
			output = "Du hast in deiner Zelle gegraben!\n";
			Cell zelle = (Cell) PrisonBreak.spieler.getCurrentRoom();
			zelle.setTunnelFortschritt(20);
			output += "Dein Fortschritt betr�gt nun: " + zelle.getTunnelFortschritt() +"\n";
			if (zelle.isTunnelCompleted()) {
				output += "Du hast es geschafft und konntest mit deinem Bruder fliehen!\n"
						+ "########### ENDE ##########";
			}
			
		}else {
			output = "Du kannst nur in deiner Zelle graben!";
		}
		return output;
	}
	
}
