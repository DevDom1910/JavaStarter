package de.webdesignfeilbach.prisonbreak.commands;

import java.util.List;

import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.repository.Auswahlkriterien;
import de.webdesignfeilbach.prisonbreak.rooms.LocationType;
import de.webdesignfeilbach.prisonbreak.rooms.Room;
/**
 * 
 * Diese Klasse dient zur Ausf�hrung der KILL Action. </br>
 * Die Klasse soll nicht instanziert werden k�nnen. </br>
 * Aufruf soll durch einen Kommando Controller erfolgen.
 * 
 * 
 * @author Dominik Feilbach
 *
 */
public abstract class KillCommand {

	public static String executeCommand(NPC bot) {

		String output = "";
		
		/**
		 * Sollte sich der Spieler nicht schon im Gef�ngnis befinden: Locationtyp = frei, wird der Spieler verhaftet und kommt ins Gef�ngnis. </br>
		 * Der Spieler bekommt eine Haftstrafe von 5 Jahren! </br>
		 * Der get�tete NPC wird aus dem Raum entfernt.
		 * 
		 * Sollte sich der Spieler im Gef�ngnis befinden: Locationtyp = gefangen, wird seine Haftstrafe um 10 Jahre erh�ht und kommt in seine Zelle. </br>
		 * Der get�tete NPC wird aus dem Raum entfernt. </br>
		 * 
		 */
		if (PrisonBreak.spieler.getCurrentRoom().getLocationTyp() == LocationType.FREI) {
			output = "Du hast " + bot.getNpcName() + " get�tet! Die Polizei verhaftet dich und du gehst 5 Jahre ins Gef�ngnis!";
			PrisonBreak.spieler.erhoehenHaftstrafe(5);
			PrisonBreak.spieler.getCurrentRoom().removeNPC(bot);
			List<Room> currentRooms = PrisonBreak.roomDiener.filtern(Auswahlkriterien.IST_ZELLE);
			PrisonBreak.spieler.setCurrentRoom(currentRooms.get(0));
		} else {
			output = "Du hast " + bot.getNpcName() + " get�tet! Deine Gef�ngnisstrafe hat sich um 10 Jahre erh�ht!";
			PrisonBreak.spieler.erhoehenHaftstrafe(10);
			PrisonBreak.spieler.getCurrentRoom().removeNPC(bot);
			List<Room> currentRooms = PrisonBreak.roomDiener.filtern(Auswahlkriterien.IST_ZELLE);
			PrisonBreak.spieler.setCurrentRoom(currentRooms.get(0));

		}

		return output;

	}

}
