package de.webdesignfeilbach.prisonbreak.rooms;

import java.util.List;
import de.webdesignfeilbach.prisonbreak.entities.NPC;

/**
 * 
 * Spezieller Raum: Dient zum erfolgreichen Beenden des Spiels. </br>
 * Spiel soll erfolgreich beendet werden, wenn der Tunnelfortschritt 100 und der Tunnel somit komplett ist. </br>
 * Zelle wird in der GameMap entsprechend der JSON DATEI erstellt. </br>
 * Zelle erbt von R�ume.
 * 
 * @author Dominik Feilbach
 *
 */

public class Cell extends Room{
	/** Tunnelfortschritt wird beim Graben erh�ht */
	private int tunnelFortschritt;
	/** Tunnel ist bei Tunnelfortschritt 100 komplett => true */
	private boolean tunnelCompleted;

	
	/**
	 * 
	 * Der Konstruktor ruft die Elternklasse Raum auf, setzt den Tunnelfortschritt auf 0 und den boolean TunnelComplete auf false.
	 * 
	 * @param roomID
	 * @param roomName
	 * @param beschreibung
	 * @param locationTyp
	 * @param gefahrenStufe
	 * @param open
	 * @param npcs
	 */
	public Cell(String roomID, String roomName, String beschreibung, LocationType locationTyp, int gefahrenStufe,
			boolean open, List<NPC> npcs) {
		super(roomID, roomName, beschreibung, locationTyp, gefahrenStufe, open, npcs);
		this.tunnelFortschritt = 0;
		this.tunnelCompleted = false;
	}

	
	//GETTER/SETTER
	/**
	 * @return the tunnelFortschritt
	 */
	public int getTunnelFortschritt() {
		return tunnelFortschritt;
	}

	/**
	 * @param tunnelFortschritt the tunnelFortschritt to set
	 */
	public void setTunnelFortschritt(int tunnelFortschritt) {
		if (this.tunnelFortschritt + tunnelFortschritt >= 100) {
			this.tunnelFortschritt = 100;
			setTunnelCompleted(true);
		}else {
			this.tunnelFortschritt += tunnelFortschritt;
		}
		
	}
	
	
	

	/**
	 * @return the tunnelCompleted
	 */
	public boolean isTunnelCompleted() {
		return tunnelCompleted;
	}

	/**
	 * @param tunnelCompleted the tunnelCompleted to set
	 */
	public void setTunnelCompleted(boolean tunnelCompleted) {
		this.tunnelCompleted = tunnelCompleted;
	}
	
	
	

	
	
	

}
