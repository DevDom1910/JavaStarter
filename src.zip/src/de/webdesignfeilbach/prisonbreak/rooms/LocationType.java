package de.webdesignfeilbach.prisonbreak.rooms;
/**
 * 
 * ENUM, zur Deklarierung des Raumtyps.
 * 
 * @author Dominik Feilbach
 *
 */
public enum LocationType {
	FREI,
	GEFANGEN;
}
