package de.webdesignfeilbach.prisonbreak.rooms;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.items.Inventory;
import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.items.ItemBundle;

/**
 * 
 * Elterklasse f�r alle weiteren R�ume. </br>
 * R�ume sollen durch die JSON Datei erstellt und in der Klasse GameMap instanziert werden
 * Jeder Raum bekommt: </br>
 * - roomID </br>
 * - Raumname </br>
 * - Beschreibung </br>
 * - Locationtyp </br>
 * - Gefahrenstufe </br>
 * - Geschlossen oder offen </br>
 * - Inventar </br>
 * - NPCS </br>
 * - Nachbarr�ume </br>
 * 
 * @author Dominik Feilbach
 *
 */

public class Room {
	/** Beispiel: zuhause */
	private String roomID;
	/** Beispiel: Zuhause */
	private String roomName;
	/** Beispiel: Dein Zuhause */
	private String beschreibung;
	/** Beispiel: FREI */
	private LocationType locationTyp;
	/** Beispiel: 0 */
	private int gefahrenStufe;
	/** Beispiel: true */
	private boolean open;
	/** Beispiel: [apfel/1, brot/1, milch/1, pistole/1] */
	private Inventory inventar;
	/** Beispiel: [Bot] */
	private List<NPC> npcs;
	/** Beispiel: [Room, Room, Room, Room] */
	private Map<String, Room> neighboursRooms;

	// KONSTRUKTOREN
	/**
	 * Nachbarr�ume und Inventar werden sp�ter durch den SETTER inder Klasse GameMap erstellt
	 * 
	 * @param roomID
	 * @param roomName
	 * @param beschreibung
	 * @param locationTyp
	 * @param gefahrenStufe
	 * @param open
	 * @param npcs
	 */
	public Room(String roomID, String roomName, String beschreibung, LocationType locationTyp, int gefahrenStufe,
			boolean open, List<NPC> npcs) {
		this.roomID = roomID;
		this.roomName = roomName;
		this.beschreibung = beschreibung;
		this.locationTyp = locationTyp;
		this.gefahrenStufe = gefahrenStufe;
		this.open = open;
		this.npcs = npcs;
		this.inventar = new Inventory();
		this.neighboursRooms = new HashMap<>();
	}
	
	/**
	 * Das gesamte Inventar wird zur�ckgegeben
	 * @return inventar
	 */
	public Inventory getInventory() {
		return inventar;
	}
	/**
	 * Liste der ItemStacks wird zur�ckgegeben
	 * @return itemBundle
	 */
	public List<ItemBundle> getItemStacks() {
		return inventar.getItemStack();
	}

	/**
	 * Hinzuf�gen einer Liste von NPCS zur aktuellen Raumliste
	 * @param npcs
	 */
	public void addNPCS(List<NPC> npcs) {
		for (NPC npc : npcs) {
			addNPC(npc);
		}
	}

	/**
	 * Hinzuf�gen eines NPC zur aktuellen Raumliste
	 * @param npc
	 */
	public void addNPC(NPC npc) {
		npcs.add(npc);
	}

	
	/**
	 * �berpr�fung, ob NPC in Raumliste und entfernen des NPC bei �bereinstimmung
	 * @param npc
	 */
	public void removeNPC(NPC npc) {
		for (NPC npcEintrag : npcs) {
			if (npcEintrag.getNpcName().equalsIgnoreCase(npc.getNpcName())) {
				npcs.remove(npcEintrag);
				break;
			}
		}
	}

	/**
	 * R�ckgabe der Raumliste. Diese ist nicht mehr modifizierbar.
	 * @return
	 */
	public List<NPC> getNpcs() {
		return Collections.unmodifiableList(npcs);
	}

	/**
	 * Entfernen eines Items ohne Anzahl </br>
	 * Aufruf der Methode removeItem mit Anzahl 1
	 * @param item
	 */
	public void removeItem(Item item) {
		this.removeItem(item, 1);
	}
	
	/**
	 * 
	 * Entfernen eines Items mit entsprechender Anzahl </br>
	 * �berpr�fung, ob Item in inventar vorhanden, bei Erfolg entfernen des Items in Inventar
	 * @param item
	 * @param amount
	 */
	public void removeItem(Item item, int amount) {
		for (ItemBundle itemBundle : inventar.getItemStack()) {
			if (itemBundle.getItem().getItemId().equalsIgnoreCase(item.getItemId())) {
				inventar.removeItem(item, amount);
			}
		}
	}

	
	/**
	 * Hinzuf�gen eines Items ohne Angabe der Anzahl. </br>
	 * Aufruf der addItem Methode mit Anzahl 1.
	 * @param item
	 */
	public void addItem(Item item) {
		this.addItem(item, 1);
	}
	
	/**
	 * Hinzuf�gen eines Items mit entsprechender Anzahl zur Rauminventarliste.
	 * @param item
	 * @param amount
	 */
	public void addItem(Item item, int amount) {
		inventar.addItem(item, amount);
	}
	

	// GETTERS/SETTERS

	/**
	 * @return the roomName
	 */
	public String getRoomName() {
		return roomName;
	}

	/**
	 * @return the roomID
	 */
	public String getRoomID() {
		return roomID;
	}

	/**
	 * @param roomName the roomName to set
	 */
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	/**
	 * @return the beschreibung
	 */
	public String getBeschreibung() {
		return beschreibung;
	}

	/**
	 * @param beschreibung the beschreibung to set
	 */
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	/**
	 * @return the locationTyp
	 */
	public LocationType getLocationTyp() {
		return locationTyp;
	}

	/**
	 * @param locationTyp the locationTyp to set
	 */
	public void setLocationTyp(LocationType locationTyp) {
		this.locationTyp = locationTyp;
	}

	/**
	 * @return the gefahrenStufe
	 */
	public int getGefahrenStufe() {
		return gefahrenStufe;
	}

	/**
	 * @param gefahrenStufe the gefahrenStufe to set
	 */
	public void setGefahrenStufe(int gefahrenStufe) {
		this.gefahrenStufe = gefahrenStufe;
	}
	
	/**
	 * @return the open
	 */
	public boolean isOpen() {
		return open;
	}

	/**
	 * @param open the open to set
	 */
	public void setOpen(boolean open) {
		this.open = open;
	}

	
	/**
	 * @return the neighboursRooms
	 */
	public Map<String, Room> getNeighboursRooms() {
		return neighboursRooms;
	}

	/**
	 * @param neighboursRooms the neighboursRooms to set
	 */
	public void setNeighboursRooms(Map<String, Room> neighboursRooms) {
		this.neighboursRooms = neighboursRooms;
	}

	@Override
	public int hashCode() {
		return Objects.hash(beschreibung, gefahrenStufe, inventar, locationTyp, neighboursRooms, npcs, open, roomID,
				roomName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Room other = (Room) obj;
		return Objects.equals(beschreibung, other.beschreibung) && gefahrenStufe == other.gefahrenStufe
				&& Objects.equals(inventar, other.inventar) && locationTyp == other.locationTyp
				&& Objects.equals(neighboursRooms, other.neighboursRooms) && Objects.equals(npcs, other.npcs)
				&& open == other.open && Objects.equals(roomID, other.roomID)
				&& Objects.equals(roomName, other.roomName);
	}

	@Override
	public String toString() {
		int contentSize = neighboursRooms.size();
		//TODO: NACHBARR�UME IN GAMEMAP INITIALISIEREN UM STACKOVERFLOW CIRCLE ZU VERMEIDEN
		
		return "Room [roomID=" + roomID + ", roomName=" + roomName + ", beschreibung=" + beschreibung + ", locationTyp="
				//+ locationTyp + ", gefahrenStufe=" + gefahrenStufe + ", open=" + open + ", inventar=" + inventar
				+ ", npcs=" + npcs 
				+ ", neighboursRooms=" + contentSize //+ neighboursRooms
				+ "]";
	}
	
	
	
	
	
	

}
