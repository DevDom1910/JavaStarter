package de.webdesignfeilbach.prisonbreak.items;

/**
 * 
 * ENUM zur Darstellung bestimmter Itemtypen
 * @author Dominik Feilbach
 *
 */
public enum ItemTyp {
	WAFFE,
	ESSEN,
	TRINKEN,
	RUESTUNG,
	WERKZEUG,
	SONSTIGES;
}
