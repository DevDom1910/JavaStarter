package de.webdesignfeilbach.prisonbreak.items;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
/**
 * 
 * Klasse Item zum erstellen von Items. </br>
 * Items liegen in jedem Raum herum und k�nnen aufgesammelt werden. </br>
 * Items werden durch die JSON Datei definiert. 
 * @author Dominik Feilbach
 *
 *
 */
public class Item {
	/** Beispiel: apfel */
	private String itemId;
	/** Beispiel: Apfel */
	private String name;
	/** Beispiel: Ein kleines St�ck Apfel */
	private String beschreibung;
	/** Beispiel: ESSEN */
	private ItemTyp typ;
	/** Beispiel: Map mit Eigenschaften: gesundheit, wert.... */
	private Map<String, Integer> eigenschaften;
	
	/**
	 * Konstruktor zum Instanzieren eines Items.
	 * @param itemId
	 * @param name
	 * @param beschreibung
	 * @param typ
	 * @param eigenschaften
	 */
	public Item(String itemId, String name, String beschreibung, ItemTyp typ, Map<String, Integer> eigenschaften) {
		this.itemId = itemId;
		this.name = name;
		this.beschreibung = beschreibung;
		this.typ = typ;
		if (eigenschaften != null) {
			this.eigenschaften = eigenschaften;
		}else {
			this.eigenschaften = new HashMap<String, Integer>();
		}
	}

	
	/**
	 * @return gewicht oder 0
	 */
	public int getGewicht() {
		if (eigenschaften.containsKey("gewicht")) {
			return eigenschaften.get("gewicht");
		}
		
		return 0;
	}
	/**
	 * @return eigenschaft oder 0
	 */
	public int getEigenschaft(String eigenschaft) {
		if (! eigenschaften.containsKey(eigenschaft)) {
			return 0;
		}
		
		return eigenschaften.get(eigenschaft);
	}
	/**
	 * @return true oder false
	 */
	public boolean containsEigenschaft(String key) {
		return eigenschaften.containsKey(key);
	}
	
	
	//GETTERS
	/**
	 * @return the itemId
	 */
	public String getItemId() {
		return itemId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the beschreibung
	 */
	public String getBeschreibung() {
		return beschreibung;
	}

	/**
	 * @return the typ
	 */
	public ItemTyp getTyp() {
		return typ;
	}

	/**
	 * Map ist nicht mehr modifizierbar!
	 * @return the eigenschaften
	 */
	public Map<String, Integer> getEigenschaften() {
		//Nicht mehr modifizierbar
		return  Collections.unmodifiableMap(eigenschaften);
	}


	@Override
	public int hashCode() {
		return Objects.hash(beschreibung, eigenschaften, itemId, name, typ);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		return Objects.equals(beschreibung, other.beschreibung) && Objects.equals(eigenschaften, other.eigenschaften)
				&& Objects.equals(itemId, other.itemId) && Objects.equals(name, other.name) && typ == other.typ;
	}


	@Override
	public String toString() {
		
		String eigenschaftenString = "";
		for (Map.Entry<String, Integer> eintrag : eigenschaften.entrySet()) {
			eigenschaftenString = eigenschaftenString + "(" + eintrag.getKey() + ": " + eintrag.getValue() + ") ";
		}
		return "Item [itemId=" + itemId + ", name=" + name + ", beschreibung=" + beschreibung + ", typ=" + typ
				+ ", eigenschaften=" + eigenschaftenString + "]";
	}
	
	
	
	
	
	
	
	
	
	
		
	
}
