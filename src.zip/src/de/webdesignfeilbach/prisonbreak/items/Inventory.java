package de.webdesignfeilbach.prisonbreak.items;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Definiert ein Inventar f�r jeden Raum und Entit�t im Spiel. </br>
 * Ein Inventar hat ein maximales Gewicht und beinhaltet Items. </br>
 * Jedes Inventar soll eine Liste von ItemBundles enthalten.
 * 
 * @author Dominik Feilbach
 *
 */
public class Inventory {
	/** Beispiel: 50 */
	private int maxGewicht;
	/** Beispiel: 0 / Initialisierung: 0 */
	private int gesamtGewicht = 0;
	
	/** Beispiel: (Item, 2) */
	private List<ItemBundle> itemBundles;
	
	
	//KONSTRUKTOREN
	/**
	 * Das Standardmaximalgewicht betr�gt 50. Die Liste der ItemBundles wird neu erstellt.
	 */
	public Inventory() {
		this.maxGewicht = 50;
		this.itemBundles = new ArrayList<ItemBundle>();
	}
	/**
	 * Das Maximalgewicht wird �bergeben. Die Liste der ItemBundles wird neu erstellt.
	 */
	public Inventory(int maxGewicht) {
		this.maxGewicht = maxGewicht;
		this.itemBundles = new ArrayList<ItemBundle>();
	}
	
	/**
	 * Das Maximalgewicht betr�gt 50. Die Liste der ItemBundles wird ebenfalls �bergeben.
	 */
	public Inventory(int maxGewicht, List<ItemBundle> itemBundles) {
		this.maxGewicht = maxGewicht;
		this.itemBundles = itemBundles;
	}
	
	/**
	 * Methode zur �berpr�fung, ob das Inventar ein bestimmtes Item enth�lt
	 * 
	 * @param itemCheck
	 * @return itemBundle oder null
	 */
	private ItemBundle contains(ItemBundle item) {
		for (ItemBundle itemBundle : this.itemBundles) {
			if (itemBundle.getItem().equals(item.getItem())) {
				return itemBundle;
			}
		}
		return null;
	}
	
	
	/**
	 * F�gt das Item mit entsprechender Anzahl hinzu. </br>
	 * Sollte das Item vorhanden sein wird das alte Item gel�scht und die Anzahl zum neuen Item hinzugef�gt. </br>
	 * Gewicht des Inventars wird entsprechend erh�ht.
	 * @param itemBundle
	 */
	public void addItem(ItemBundle itemBundle) {
		boolean canAdded = maxGewicht > (gesamtGewicht + itemBundle.getItem().getGewicht() * itemBundle.getAmount());
		
		if (canAdded) {
			ItemBundle gleichesBundle = this.contains(itemBundle);
			if (gleichesBundle != null) {
				int amountAlt = gleichesBundle.getAmount();
				int amountNeu = itemBundle.getAmount();
				this.itemBundles.remove(gleichesBundle);
				itemBundle.setAmount(amountAlt + amountNeu);
				itemBundles.add(itemBundle);
			}else {
				itemBundles.add(itemBundle);
			}
			gesamtGewicht = gesamtGewicht +  (itemBundle.getAmount() * itemBundle.getItem().getGewicht());
		}
		
		
	}
	/**
	 * F�gt Item mit gegebener Anzahl hinzu.
	 * @param item
	 * @param amount
	 */
	public void addItem(Item item, int amount) {
		addItem(new ItemBundle(amount, item));
	}
	/**
	 * F�gt Item mit Anzahl 1 hinzu.
	 * @param item
	 */
	public void addItem(Item item) {
		addItem(new ItemBundle(1, item));
	}
	
	
	/**
	 * 
	 * Item wird in entsprechender Menge entfernt, sollte das Item im Inventar vorhanden sein. </br>
	 * Sollte die Menge kleiner als 0 sein, wird das Item komplett aus dem Inventar entfernt.
	 * 
	 * @param itemBundle
	 * @param amount
	 * @return ItemBundle oder null bei nicht Erfolg
	 */
	public ItemBundle removeItem(ItemBundle itemBundle, int amount) {
		ItemBundle selberTyp = this.contains(itemBundle);
		if (selberTyp != null) {
			if (selberTyp.getAmount() - amount <= 0) {
				gesamtGewicht = gesamtGewicht - (selberTyp.getAmount() * selberTyp.getItem().getGewicht());
				itemBundles.remove(selberTyp);
				
			}else {
				gesamtGewicht = gesamtGewicht - (itemBundle.getItem().getGewicht() * amount);
				selberTyp.setAmount(selberTyp.getAmount() - amount);
			}
			return itemBundle;
		}
		return null;
	}
	
	/**
	 * Entfernt ein Item mit bestimmter Anzahl
	 * @param item
	 * @param amount
	 */
	public ItemBundle removeItem(Item item, int amount) {
		return removeItem(new ItemBundle(0, item), amount);
	}
	/**
	 * Entfernt Item mit Anzahl 1
	 * @param item
	 */
	public ItemBundle removeItem(Item item) {
		return removeItem(new ItemBundle(0, item), 1);
	}
	
	/**
	 * �berpr�fung, ob Inventar leer ist.
	 * @return true oder false
	 */
	public boolean isEmpty() {
        return this.itemBundles.isEmpty();
    }
	
	
	/**
	 * Suche nach einem bestimmten Item.
	 * @param name
	 * @return itemBundle oder null
	 */
	public ItemBundle getItem(String name) {
        for (ItemBundle itemBundle : itemBundles) {
            if (itemBundle.getItem().getName().equalsIgnoreCase(name)) {
                return itemBundle;
            }
        }
        return null;
    }

	
	
	

	@Override
	public String toString() {
		return "Inventory [maxGewicht=" + maxGewicht + ", gesamtGewicht=" + gesamtGewicht + ", itemBundles="
			+ itemBundles + "]";
	}

	//GETTERS/SETTERS
	public int getMaxGewicht() {
		return maxGewicht;
	}
	
	public List<ItemBundle> getItemStack() {
        return itemBundles;
    }
	
	
	
}
