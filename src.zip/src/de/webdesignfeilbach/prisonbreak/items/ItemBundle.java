package de.webdesignfeilbach.prisonbreak.items;

/**
 * 
 * Klasse wird ben�tigt, um in der Klasse Inventory die Anzahl der gleichen Items zu erh�hen.
 * 
 * @author Dominik Feilbach
 *
 */
public class ItemBundle {
	private int amount;
	private Item item;

	public ItemBundle(Item item) {
		this.amount = 1;
		this.item = item;
	}
	
	public ItemBundle(int amount, Item item) {
		this.amount = amount;
		this.item = item;
	}

	public int getAmount() {
		return this.amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Item getItem() {
		return this.item;
	}

	@Override
	public String toString() {

		return "ItemBundle [amount=" + amount + ", item=" + item + "]";
	}
	
	
	
}
