package de.webdesignfeilbach.prisonbreak.gameplay;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.webdesignfeilbach.prisonbreak.items.Item;
import de.webdesignfeilbach.prisonbreak.repository.Auswahlkriterien;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAO;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.ItemService;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAO;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import de.webdesignfeilbach.prisonbreak.rooms.Room;


/**
 * Diese Klasse konstruiert die gesamte Karte des Spiels. </br>
 * Hier werden alle R�ume und Items anhand der JSON Dateien instanziert. </br>
 * Es werden allen R�umen die entsprechenden ITEMS und NACHBARR�UME zugeordnet.
 * 
 * 
 * @author Dominik Feilbach
 *
 */
public class GameMap {
	private ItemService itemService;
	private RoomService roomService;
	private List<Item> alleItems;
	private List<Room> alleRooms;
	

	
	/**
	 * Die Parameter sollen �bergeben werden, um unabh�ngig von der GUI zu bleiben.
	 * 
	 * @param itemService
	 * @param roomService
	 */
	public GameMap(ItemService itemService, RoomService roomService) {
		this.itemService = itemService;
		this.roomService = roomService;
		createGameMap();
	}
	

	private void createGameMap() {
		createAllItems();
		createAllRooms();

	}
	
	
	


	private void createAllItems() {
		alleItems = itemService.getAlleItems();
		
	}
	
	private void createAllRooms() {		
		alleRooms = roomService.getAlleRooms();
		
		
		/**
		 * Hier werden alle R�ume initialisiert nach entsprechendem Auswahlkriterium
		 */
		//ROOMS
		List<Room> zuhause = roomService.filtern(Auswahlkriterien.IST_ZUHAUSE);
		List<Room> supermarkt = roomService.filtern(Auswahlkriterien.IST_SUPERMARKT);
		List<Room> bank = roomService.filtern(Auswahlkriterien.IST_BANK);
		List<Room> tattoostudio = roomService.filtern(Auswahlkriterien.IST_TATTOOSTUDIO);
		List<Room> zelle = roomService.filtern(Auswahlkriterien.IST_ZELLE);
		List<Room> wachraum = roomService.filtern(Auswahlkriterien.IST_WACHRAUM);
		List<Room> hof = roomService.filtern(Auswahlkriterien.IST_HOF);
		List<Room> flur = roomService.filtern(Auswahlkriterien.IST_FLUR);
		
		/**
		 * Hier werden alle Items initialisiert nach entsprechendem Auswahlkriterium
		 */
		//ITEM
		List<Item> apfel = itemService.filtern(Auswahlkriterien.IST_APFEL);
		List<Item> brot = itemService.filtern(Auswahlkriterien.IST_BROT);
		List<Item> milch = itemService.filtern(Auswahlkriterien.IST_MILCH);
		List<Item> pistole = itemService.filtern(Auswahlkriterien.IST_PISTOLE);
		List<Item> messer = itemService.filtern(Auswahlkriterien.IST_MESSER);
		List<Item> schluessel = itemService.filtern(Auswahlkriterien.IST_SCHLUESSEL);
		List<Item> wasser = itemService.filtern(Auswahlkriterien.IST_WASSER);
		
		
		/** Alle R�ume au�erhalb */
		//ADD ALL TOGETHER
		zuhause.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(messer.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", tattoostudio.get(0));
			neighbours.put("east", supermarkt.get(0));
			neighbours.put("south", null);
			neighbours.put("west", bank.get(0));
			room.setNeighboursRooms(neighbours);
		});
		
		supermarkt.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(wasser.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", null);
			neighbours.put("east", tattoostudio.get(0));
			neighbours.put("south", bank.get(0));
			neighbours.put("west", zuhause.get(0));
			room.setNeighboursRooms(neighbours);
		});
		
		bank.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(pistole.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", supermarkt.get(0));
			neighbours.put("east", zuhause.get(0));
			neighbours.put("south", tattoostudio.get(0));
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		
		tattoostudio.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(wasser.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", supermarkt.get(0));
			neighbours.put("east", bank.get(0));
			neighbours.put("south", zuhause.get(0));
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		
		
		
		
		/** Alle R�ume innerhalb */
		flur.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(wasser.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", wachraum.get(0));
			neighbours.put("east", zelle.get(0));
			neighbours.put("south", hof.get(0));
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		zelle.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(milch.get(0));
			room.addItem(wasser.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", flur.get(0));
			neighbours.put("east", null);
			neighbours.put("south", null);
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		wachraum.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(brot.get(0));
			room.addItem(messer.get(0));
			room.addItem(pistole.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", flur.get(0));
			neighbours.put("east", null);
			neighbours.put("south", null);
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		hof.forEach(room -> {
			room.addItem(apfel.get(0));
			room.addItem(pistole.get(0));
			room.addItem(schluessel.get(0));
			room.addItem(messer.get(0));
			Map<String, Room> neighbours = new HashMap<>();
			neighbours.put("north", flur.get(0));
			neighbours.put("east", null);
			neighbours.put("south",null);
			neighbours.put("west", null);
			room.setNeighboursRooms(neighbours);
		});
		
		
			
	}


	

	
	
	
	
	
	
	
	
}
	

