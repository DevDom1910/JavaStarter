package de.webdesignfeilbach.prisonbreak.game;


import java.util.List;

import de.webdesignfeilbach.prisonbreak.GUI.controller.Controller;
import de.webdesignfeilbach.prisonbreak.GUI.view.LoginView;
import de.webdesignfeilbach.prisonbreak.entities.Player;
import de.webdesignfeilbach.prisonbreak.gameplay.GameMap;
import de.webdesignfeilbach.prisonbreak.repository.Auswahlkriterien;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAO;
import de.webdesignfeilbach.prisonbreak.repository.ItemDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.ItemService;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAO;
import de.webdesignfeilbach.prisonbreak.repository.RoomDAOImplJSON;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import de.webdesignfeilbach.prisonbreak.rooms.Room;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Main Klasse zum Starten der Anwendung. </br>
 * Hier werden alle R�ume, Items, und die GameMap instanziert.</br>
 * Spieler, Stage, ItemService, RoomService sollen ohne Instamzierung zug�nglich sein.</br>
 * 
 * 
 * Ben�tigte Libs: </br>
 * - GSON </br>
 * - JAVAFX
 * 
 * 
 * @author Dominik Feilbach
 *
 */
public class PrisonBreak extends Application {
	/** Attribute sollen ohne Instanzierung zug�nglich sein, um einfachere Anpassungen vornehmen zu k�nnen */
	public static Player spieler;
	public static Stage stage;
	public static ItemService itemDiener;
	public static RoomService roomDiener;

	@Override
	public void start(Stage stage) {
		if (stage == null) {
			throw new IllegalArgumentException("Stage kann nicht null sein");
		}	
		/** Laden der R�ume und Items. */
		RoomDAO raumquelle = new RoomDAOImplJSON();
		ItemDAO itemquelle = new ItemDAOImplJSON();
		roomDiener = new RoomService(raumquelle);
		itemDiener = new ItemService(itemquelle);

		PrisonBreak.stage = stage;
		
		/** Erstellen der GameMap (�bergabe der Parameter zur Unabh�ngigkeit von der GUI. */
		new GameMap(itemDiener, roomDiener);
		
		/** Laden der Startposition des Spielers. */
		List<Room> currentRooms = roomDiener.filtern(Auswahlkriterien.IST_ZUHAUSE);
		/** Instanzieren des Spielers mit Standardnamen: Hans Flexibel */
		PrisonBreak.spieler = new Player("Hans Flexibel", currentRooms.get(0));
				
		
		/** Start des Spiels setzen => LOGIN  */
		Controller.render(new LoginView().getScene());
		stage.setTitle("Prisonbreak - The Game");
		stage.show();
	}
	
	/**
	 * Main wird als Workaround gebraucht, damit zu 100% start() aufgerufen wird.
	 * @param args
	 */
	public static void main(String[] args) {
		launch();
	}

}

