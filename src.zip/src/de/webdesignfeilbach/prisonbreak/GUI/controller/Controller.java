package de.webdesignfeilbach.prisonbreak.GUI.controller;
/**
 * 
 * Der Controller rendert die entsprechende View. </br>
 * Der Controller soll nicht instanziert werden k�nnen. 
 * 
 * @author Dominik Feilbach
 *
 */


import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.repository.ItemService;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import javafx.scene.Scene;
import javafx.stage.Stage;

public abstract class Controller {	
	
	/**
	 * Erstellte Scene in der View muss �bergeben werden und setzt anschlie�end die Scene in die Primary Stage
	 * 
	 * @param scene
	 */
	public static void render(Scene scene) {
		PrisonBreak.stage.setScene(scene);
	}
	
	
	
	
}
