/**
 * 
 */
package de.webdesignfeilbach.prisonbreak.GUI.view;

import javafx.scene.Scene;

/**
 * 
 * Interface zur �bereinstimmung der Views.
 * @author Dominik Feilbach
 *
 */
public interface ViewBuilder {

	public Scene getScene();
}
