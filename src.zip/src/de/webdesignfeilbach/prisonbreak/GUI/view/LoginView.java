package de.webdesignfeilbach.prisonbreak.GUI.view;


import de.webdesignfeilbach.prisonbreak.GUI.controller.Controller;
import de.webdesignfeilbach.prisonbreak.entities.Player;
import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.repository.ItemService;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;


/**
 * 
 * LoginView: </br>
 * Erstellen des Logins. Name darf nicht leer sein.
 * Load Button befindet sich in Bearbeitung
 * 
 * @author Dominik Feilbach
 *
 */


public class LoginView implements ViewBuilder{

	/** Textfeld zur Namenseingabe */
	private TextField userName;
	/** Buttons zur Interaktion */
	private Button submit;
	private Button load;
	
	
	@Override
	public Scene getScene() {
		BorderPane root = new BorderPane();
		root.setPadding(new Insets(20));
		
		//LOGIN BOX
		VBox vBox = new VBox();
		//�BERSCHRIFT
		Text begruessung = new Text("Herzlich Willkommen!");
		begruessung.setTextAlignment(TextAlignment.CENTER);
		

		//NAMENSBOX
		HBox nameBox = new HBox();
		
		Label user = new Label("Enter Name:");
		nameBox.setMargin(user, new Insets(20,20,20,0));
		userName = new TextField();
		nameBox.setMargin(userName, new Insets(20,20,20,0));
		nameBox.getChildren().addAll(user, userName);
		
		//BUTTONBOX
		HBox buttonBox = new HBox();
		submit = new Button("Submit");
		buttonBox.setMargin(submit, new Insets(0,10,0,0));
		load = new Button("Load");
		buttonBox.getChildren().addAll(submit, load);
		

		vBox.getChildren().addAll(begruessung, nameBox, buttonBox);
		root.setCenter(vBox);
		
		createEventHandler();
		
		return new Scene(root);
	}
	
	
	private void createEventHandler() {
		
		submit.setOnAction(event ->{
			String input = userName.getText();
			PrisonBreak.spieler.setName(input);
			Controller.render(new GameView().getScene());
			
		});
		
	}
	
}
