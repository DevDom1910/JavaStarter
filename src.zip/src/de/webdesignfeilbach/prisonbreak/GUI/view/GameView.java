package de.webdesignfeilbach.prisonbreak.GUI.view;

import java.util.Map;
import java.util.Map.Entry;

import de.webdesignfeilbach.prisonbreak.commands.Commands;
import de.webdesignfeilbach.prisonbreak.entities.NPC;
import de.webdesignfeilbach.prisonbreak.entities.Player;
import de.webdesignfeilbach.prisonbreak.game.PrisonBreak;
import de.webdesignfeilbach.prisonbreak.items.ItemBundle;
import de.webdesignfeilbach.prisonbreak.repository.RoomService;
import de.webdesignfeilbach.prisonbreak.rooms.Room;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * 
 * GameFenster! Besteht aus: </br>
 * - Ausgabenfenster </br>
 * - Kommandoeingabefenster </br>
 * - Richtungskreuz </br>
 * - Save Button: Befindet sich in Bearbeitung </br>
 * - Exit Button
 * - Inventar des Spielers: Befindet sich in Bearbeitung </br>
 * 
 * @author Dominik Feilbach
 *
 */


public class GameView{

	/** Buttons des Richtungskreuzes (werden mit entsprechenden Nachbarr�umen beschriftet */
	private Button northButton;
	private Button westButton;
	private Button eastButton;
	private Button southButton;
	
	/** Sonstige Buttons */
	private Button saveButton;
	private Button exitButton;

	/** Kommandoeingabefenster */
	private TextField userInput;
	/** Ausgabenfenster */
	private TextArea gameArea;
	/** Tooltip zur Ausgabe der Befehle */
	private Tooltip toolTip = new Tooltip();

	
	
	
	public Scene getScene() {
		BorderPane main = new BorderPane();

		HBox topBox = new HBox();
		Text welcomeLabel = new Text("Prison Break - The Game");
		welcomeLabel.setStyle("-fx-font-family: 'Press Start 2P', cursive;" + "-fx-font-size: 25px;");
		topBox.setPadding(new Insets(20));
		topBox.setAlignment(Pos.BASELINE_CENTER);
		topBox.getChildren().add(welcomeLabel);
		main.setTop(topBox);

		VBox leftBox = new VBox();
		Text inventarText = new Text("Inventar:");
		inventarText.setStyle("-fx-font-family: 'Press Start 2P', cursive;" + "-fx-font-size: 15px;");
		leftBox.setPadding(new Insets(0, 10, 10, 10));
		leftBox.setAlignment(Pos.BASELINE_CENTER);
		Text inventarListe1 = new Text("TEST");
		leftBox.setMargin(inventarListe1, new Insets(5, 0, 5, 0));
		Text inventarListe2 = new Text("TEST");
		leftBox.setMargin(inventarListe2, new Insets(5, 0, 5, 0));

		leftBox.getChildren().addAll(inventarText, inventarListe1, inventarListe2);
		main.setLeft(leftBox);

		VBox centerBox = new VBox();
		centerBox.setAlignment(Pos.CENTER);
		gameArea = new TextArea();
		printToPlayerScreen("Willkommen " + PrisonBreak.spieler.getName()
				+ ", \nDeine Mission: Rette deinen Bruder!\nEr sitzt im Gef�ngnis und wartet auf die Todesstrafe.\nDu bist zur Zeit in deinem Appartment!");
		gameArea.setEditable(false);
		gameArea.setPrefHeight(300);
		userInput = new TextField();
		userInput.setPrefHeight(200);
		userInput.setAlignment(Pos.TOP_LEFT);
		
		toolTip.setText("########### BEFEHLE ###########\n"
						+ "KILL: kill {Name NPC} -> kill Manfred\n"
						+ "DIG: dig");
		toolTip.setStyle("-fx-font: normal bold 15 ComicSansMS; "
			    + "-fx-base: #AE3522; "
			    + "-fx-text-fill: orange;");
		userInput.setTooltip(toolTip);
		
		centerBox.setMargin(userInput, new Insets(25, 0, 25, 0));
		centerBox.getChildren().addAll(gameArea, userInput);
		main.setCenter(centerBox);

		VBox rightBox = new VBox();
		rightBox.setPadding(new Insets(0, 10, 10, 10));
		rightBox.setAlignment(Pos.CENTER);
		northButton = new Button("NORTH");
		northButton.setPrefWidth(100);
		HBox helperBox = new HBox();
		helperBox.setAlignment(Pos.CENTER);
		westButton = new Button("WEST");
		westButton.setPrefWidth(100);
		eastButton = new Button("EAST");
		eastButton.setPrefWidth(100);
		helperBox.getChildren().addAll(westButton, eastButton);
		southButton = new Button("SOUTH");
		southButton.setPrefWidth(100);
		rightBox.getChildren().addAll(northButton, helperBox, southButton);
		main.setRight(rightBox);

		HBox bottomBox = new HBox();
		bottomBox.setAlignment(Pos.BASELINE_RIGHT);
		bottomBox.setPadding(new Insets(20));
		saveButton = new Button("Save");
		saveButton.setPrefSize(100, 20);
		bottomBox.setMargin(saveButton, new Insets(0, 10, 0, 0));
		exitButton = new Button("Exit");
		exitButton.setPrefSize(100, 20);
		Label timeLabel = new Label("Deine Zeit: " + "12:30:00");
		bottomBox.setMargin(exitButton, new Insets(0, 10, 0, 0));
		bottomBox.getChildren().addAll(saveButton, exitButton, timeLabel);
		main.setBottom(bottomBox);

		changeButtonDescription();
		createEventHandler();

		return new Scene(main, 1000, 500);
	}

	/**
	 * Methode bei der die Kommandozeile durch ENTER ausgelesen und die Eingabe verarbeitet wird 
	 */
	private void enterPressed() {
		String input = userInput.getText().toLowerCase();
		if ("quit".equals(input) || "exit".equals(input)) {
			printToPlayerScreen("Du hast das Spiel beendet!");
			System.exit(-1);
		} else {
			printToPlayerScreen(Commands.analyzeCommands(PrisonBreak.spieler, input));
			changeButtonDescription();

		}

		userInput.clear();
	}

	/**
	 * Ausgabe des �bergebenen Strings auf das Ausgabefenster
	 * @param output
	 */
	public void printToPlayerScreen(String output) {
		gameArea.setText(gameArea.getText() + output
				+ "\n*******************************************************************************************************\n");
		gameArea.selectPositionCaret(gameArea.getLength() + 1);
		gameArea.deselect();
	}

	/**
	 * Ver�nderung des Buttonbeschriftung des Richtungskreuzes entsprechend des aktuellen Raums
	 */
	private void changeButtonDescription() {
		
			Map<String, Room> neighboursMap = PrisonBreak.spieler.getCurrentRoom().getNeighboursRooms();
			for (Entry<String, Room> entry : neighboursMap.entrySet()) {
				if (entry.getKey().equalsIgnoreCase("north")) {
					if (entry.getValue() == null) {
						northButton.setText("Kein Ausgang");
					} else {
						northButton.setText(entry.getValue().getRoomID());
					}

				} else if (entry.getKey().equalsIgnoreCase("east")) {
					if (entry.getValue() == null) {
						eastButton.setText("Kein Ausgang");
					} else {
						eastButton.setText(entry.getValue().getRoomID());
					}
				} else if (entry.getKey().equalsIgnoreCase("south")) {
					if (entry.getValue() == null) {
						southButton.setText("Kein Ausgang");
					} else {
						southButton.setText(entry.getValue().getRoomID());
					}

				} else if (entry.getKey().equalsIgnoreCase("west")) {
					if (entry.getValue() == null) {
						westButton.setText("Kein Ausgang");
					} else {
						westButton.setText(entry.getValue().getRoomID());
					}

				}
			}
		
	}

	/** Eventhandler */
	private void createEventHandler() {
		
		/** Exit Button zum Beenden des Spiels */
		exitButton.setOnAction(event -> {
			System.exit(-1);
		});

		/** Kommandoeingabefenster, welches auf Enter reagiert */
		userInput.setOnAction(event -> {
			enterPressed();
		});

		/**
		 * Button aus Drehkreuz gibt im Ausgabefenster den Raumwechsel mit entsprechendem Inventar, NPC und Beschreibung aus.
		 */
		northButton.setOnAction(event -> {
			Map<String, Room> neighboursMap = PrisonBreak.spieler.getCurrentRoom().getNeighboursRooms();
			for (Entry<String, Room> entry : neighboursMap.entrySet()) {
				if (entry.getKey().equalsIgnoreCase("north")) {

					if (entry.getValue() == null) {
						printToPlayerScreen("Kein Ausgang");
					} else {

						PrisonBreak.spieler.setCurrentRoom(entry.getValue());
						changeButtonDescription();
						String roomOutputString = "Raumwechsel:\n";
						roomOutputString += "Raum: " + PrisonBreak.spieler.getCurrentRoom().getRoomName() + "\n";
						roomOutputString += "Beschreibung: " + PrisonBreak.spieler.getCurrentRoom().getBeschreibung()
								+ "\n";
						roomOutputString += "Gefahrenstufe: " + PrisonBreak.spieler.getCurrentRoom().getGefahrenStufe()
								+ "\n";

						for (NPC npc : PrisonBreak.spieler.getCurrentRoom().getNpcs()) {
							roomOutputString += "NPC: " + npc.getNpcName() + "\n";
						}
						for (ItemBundle itemstack : PrisonBreak.spieler.getCurrentRoom().getItemStacks()) {
							roomOutputString += itemstack.getAmount() + "x " + itemstack.getItem().getName() + "\n";
						}
						printToPlayerScreen(roomOutputString);
					}
				}
			}
		});
		
		/**
		 * Button aus Drehkreuz gibt im Ausgabefenster den Raumwechsel mit entsprechendem Inventar, NPC und Beschreibung aus.
		 */
		eastButton.setOnAction(event -> {
			Map<String, Room> neighboursMap = PrisonBreak.spieler.getCurrentRoom().getNeighboursRooms();
			for (Entry<String, Room> entry : neighboursMap.entrySet()) {
				if (entry.getKey().equalsIgnoreCase("east")) {
					if (entry.getValue() == null) {
						printToPlayerScreen("Kein Ausgang");
					} else {
						PrisonBreak.spieler.setCurrentRoom(entry.getValue());
						changeButtonDescription();
						String roomOutputString = "Raumwechsel:\n";
						roomOutputString += "Raum: " + PrisonBreak.spieler.getCurrentRoom().getRoomName() + "\n";
						roomOutputString += "Beschreibung: " + PrisonBreak.spieler.getCurrentRoom().getBeschreibung()
								+ "\n";
						roomOutputString += "Gefahrenstufe: " + PrisonBreak.spieler.getCurrentRoom().getGefahrenStufe()
								+ "\n";

						for (NPC npc : PrisonBreak.spieler.getCurrentRoom().getNpcs()) {
							roomOutputString += "NPC: " + npc.getNpcName() + "\n";
						}
						for (ItemBundle itemstack : PrisonBreak.spieler.getCurrentRoom().getItemStacks()) {
							roomOutputString += itemstack.getAmount() + "x " + itemstack.getItem().getName() + "\n";
						}
						printToPlayerScreen(roomOutputString);
					}
				}
			}
		});

		/**
		 * Button aus Drehkreuz gibt im Ausgabefenster den Raumwechsel mit entsprechendem Inventar, NPC und Beschreibung aus.
		 */
		southButton.setOnAction(event -> {
			Map<String, Room> neighboursMap = PrisonBreak.spieler.getCurrentRoom().getNeighboursRooms();
			for (Entry<String, Room> entry : neighboursMap.entrySet()) {
				if (entry.getKey().equalsIgnoreCase("south")) {
					if (entry.getValue() == null) {
						printToPlayerScreen("Kein Ausgang");
					} else {
						PrisonBreak.spieler.setCurrentRoom(entry.getValue());
						changeButtonDescription();
						String roomOutputString = "Raumwechsel:\n";
						roomOutputString += "Raum: " + PrisonBreak.spieler.getCurrentRoom().getRoomName() + "\n";
						roomOutputString += "Beschreibung: " + PrisonBreak.spieler.getCurrentRoom().getBeschreibung()
								+ "\n";
						roomOutputString += "Gefahrenstufe: " + PrisonBreak.spieler.getCurrentRoom().getGefahrenStufe()
								+ "\n";

						for (NPC npc : PrisonBreak.spieler.getCurrentRoom().getNpcs()) {
							roomOutputString += "NPC: " + npc.getNpcName() + "\n";
						}
						for (ItemBundle itemstack : PrisonBreak.spieler.getCurrentRoom().getItemStacks()) {
							roomOutputString += itemstack.getAmount() + "x " + itemstack.getItem().getName() + "\n";
						}
						printToPlayerScreen(roomOutputString);
					}
				}
			}
		});

		/**
		 * Button aus Drehkreuz gibt im Ausgabefenster den Raumwechsel mit entsprechendem Inventar, NPC und Beschreibung aus.
		 */
		westButton.setOnAction(event -> {
			Map<String, Room> neighboursMap = PrisonBreak.spieler.getCurrentRoom().getNeighboursRooms();
			for (Entry<String, Room> entry : neighboursMap.entrySet()) {

				if (entry.getKey().equalsIgnoreCase("west")) {
					if (entry.getValue() == null) {
						printToPlayerScreen("Kein Ausgang");
					} else {
						PrisonBreak.spieler.setCurrentRoom(entry.getValue());
						changeButtonDescription();
						String roomOutputString = "Raumwechsel:\n";
						roomOutputString += "Raum: " + PrisonBreak.spieler.getCurrentRoom().getRoomName() + "\n";
						roomOutputString += "Beschreibung: " + PrisonBreak.spieler.getCurrentRoom().getBeschreibung()
								+ "\n";
						roomOutputString += "Gefahrenstufe: " + PrisonBreak.spieler.getCurrentRoom().getGefahrenStufe()
								+ "\n";

						for (NPC npc : PrisonBreak.spieler.getCurrentRoom().getNpcs()) {
							roomOutputString += "NPC: " + npc.getNpcName() + "\n";
						}
						for (ItemBundle itemstack : PrisonBreak.spieler.getCurrentRoom().getItemStacks()) {
							roomOutputString += itemstack.getAmount() + "x " + itemstack.getItem().getName() + "\n";
						}
						printToPlayerScreen(roomOutputString);
					}
				}
			}
		});
	}

}
